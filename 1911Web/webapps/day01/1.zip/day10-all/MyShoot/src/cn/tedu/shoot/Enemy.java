package cn.tedu.shoot;
/** �÷ֽӿ� */
public interface Enemy {
	/** �÷� */
	public int getScore();
}

















